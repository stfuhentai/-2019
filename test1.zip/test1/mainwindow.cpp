#include <QtWidgets>
#include "mainwindow.h"
#include "exif.h"
int argc;
int H = 720;
int W = 1280;
QString strH;
QString strW;
QString filePath;
QString strMetaData;
QString strMetaData1;
QString strMetaData2;
QString strMetaData3;
QString strMetaData4;
QString strMetaData5;
QString strMetaData6;
QString strMetaData7;
QString strMetaData8;
QString strMetaData9;
QString strMetaData10;
QString strMetaData11;
QString strMetaData12;
QString strMetaData13;
QString strMetaData14;
QString strMetaData15;
QString strMetaData16;
MainWindow::MainWindow()
{
setWindowTitle(tr("Gallery"));
resize(1600,900);
fileLabel=new QLabel(this);
fileLabel->setGeometry(10,5,850,120);
fileLabel->setFont(QFont("Courier",18,QFont::Bold));
fileLabel->setText("Open: "+filePath);
pathEdit=new QLineEdit(this);
pathEdit->setText(filePath);
pathEdit->setGeometry(10,130,850,30);
fileLabel->setFont(QFont("System",12,QFont::Bold));
fileLabel->setText(filePath);
labLabel = new QLabel(this);
labLabel->setGeometry(10, 0, 850, 40);
labLabel->setFont(QFont("Courier", 14, QFont::Bold));
labLabel->setText("Change Height and Width");
lab1Label = new QLabel(this);
lab1Label->setGeometry(1350, 130, 850, 40);
lab1Label->setFont(QFont("Courier", 18, QFont::Bold));
hLabel=new QLabel(this);
hLabel->setGeometry(10,65,60,40);
hLabel->setFont(QFont("Courier",18,QFont::Bold));
hLabel->setText("H");
hEdit=new QLineEdit(this);
hEdit->setGeometry(30,70,100,30);
hEdit->setFont(QFont("System",12,QFont::Normal));
hEdit->setText(strH);
wLabel=new QLabel(this);
wLabel->setGeometry(10,30,60,40);
wLabel->setFont(QFont("Courier",18,QFont::Bold));
wLabel->setText("W");
wEdit=new QLineEdit(this);
wEdit->setGeometry(30,35,100,30);
wEdit->setFont(QFont("System",12,QFont::Normal));
wEdit->setText(strW);

metaLabel = new QLabel(this);
metaLabel->setGeometry(1350, 160, 850, 120);
metaLabel->setFont(QFont("Courier", 18, QFont::Bold));
meta1Label = new QLabel(this);
meta1Label->setGeometry(1350, 180, 850, 120);
meta1Label->setFont(QFont("Courier", 18, QFont::Bold));
meta2Label = new QLabel(this);
meta2Label->setGeometry(1350, 200, 850, 120);
meta2Label->setFont(QFont("Courier", 18, QFont::Bold));
meta3Label = new QLabel(this);
meta3Label->setGeometry(1350, 220, 850, 120);
meta3Label->setFont(QFont("Courier", 18, QFont::Bold));
meta4Label = new QLabel(this);
meta4Label->setGeometry(1350, 240, 850, 120);
meta4Label->setFont(QFont("Courier", 18, QFont::Bold));
meta5Label = new QLabel(this);
meta5Label->setGeometry(1350, 260, 850, 120);
meta5Label->setFont(QFont("Courier", 18, QFont::Bold));
meta6Label = new QLabel(this);
meta6Label->setGeometry(1350, 280, 850, 120);
meta6Label->setFont(QFont("Courier", 18, QFont::Bold));
meta7Label = new QLabel(this);
meta7Label->setGeometry(1350, 300, 850, 120);
meta7Label->setFont(QFont("Courier", 18, QFont::Bold));
meta8Label = new QLabel(this);
meta8Label->setGeometry(1350, 320, 850, 120);
meta8Label->setFont(QFont("Courier", 18, QFont::Bold));
meta9Label = new QLabel(this);
meta9Label->setGeometry(1350, 340, 850, 120);
meta9Label->setFont(QFont("Courier", 18, QFont::Bold));
meta10Label = new QLabel(this);
meta10Label->setGeometry(1350,360, 850, 120);
meta10Label->setFont(QFont("Courier", 18, QFont::Bold));
meta11Label = new QLabel(this);
meta11Label->setGeometry(1350, 380, 850, 120);
meta11Label->setFont(QFont("Courier", 18, QFont::Bold));
meta12Label = new QLabel(this);
meta12Label->setGeometry(1350, 400, 850, 120);
meta12Label->setFont(QFont("Courier", 18, QFont::Bold));
meta13Label = new QLabel(this);
meta13Label->setGeometry(1350, 420, 850, 120);
meta13Label->setFont(QFont("Courier", 18, QFont::Bold));
meta14Label = new QLabel(this);
meta14Label->setGeometry(1350, 440, 850, 120);
meta14Label->setFont(QFont("Courier", 18, QFont::Bold));
meta15Label = new QLabel(this);
meta15Label->setGeometry(1350, 460, 850, 120);
meta15Label->setFont(QFont("Courier", 18, QFont::Bold));
meta16Label = new QLabel(this);
meta16Label->setGeometry(1350, 480, 850, 120);
meta16Label->setFont(QFont("Courier", 18, QFont::Bold));

QPushButton* changeButton = new QPushButton(tr("Change"), this);
changeButton->setGeometry(140, 49, 100, 35);
changeButton->setFont(QFont("Times", 18, QFont::Bold));
connect(changeButton, SIGNAL(clicked()), this, SLOT(changeButtonClick()));

QPushButton *openButton=new QPushButton(tr("Open"),this);
openButton->setGeometry(10,180,75,30);
openButton->setFont(QFont("Times",18,QFont::Bold));
connect(openButton,SIGNAL(clicked()),this,SLOT(openButtonClick()));

}
void MainWindow::changeButtonClick()
{
	strH = hEdit->text();
	H = strH.toInt();
	strW = wEdit->text();
	W = strW.toInt();
}
void MainWindow::openButtonClick()
{
	filePath = pathEdit->text();
	openImage();
	pathEdit->setText(filePath);
	update();
		QFile file(filePath);
		if (file.open(QIODevice::ReadOnly)) {
			QByteArray data = file.readAll();
			easyexif::EXIFInfo info;
			if (int code = info.parseFrom((unsigned char*)data.data(), data.size())) 
			{
			}
			strMetaData = info.Model.c_str();
			strMetaData1 = info.Make.c_str();
			strMetaData2 = info.Model.c_str();
			strMetaData3 = info.Software.c_str();
			strMetaData4.setNum(info.ImageWidth);
			strMetaData5.setNum(info.ImageHeight);
			strMetaData6.setNum(info.Orientation);
			strMetaData7 = info.DateTime.c_str();
			strMetaData8 = info.DateTimeOriginal.c_str();
			strMetaData9 = info.DateTimeDigitized.c_str();
			strMetaData10 = info.SubSecTimeOriginal.c_str();
			strMetaData11.setNum((unsigned)(1.0 / info.ExposureTime));
			strMetaData12.setNum(info.FNumber);
			strMetaData13.setNum(info.ISOSpeedRatings);
			strMetaData14.setNum(info.MeteringMode);
			strMetaData15.setNum(info.FocalLength);
			strMetaData16.setNum(info.FocalLengthIn35mm);
			lab1Label->setText("MetaData picture");
			metaLabel->setText("Camera model      : " + strMetaData);
			meta1Label->setText("Camera make       : " + strMetaData1);
			meta2Label->setText("Camera model      : " + strMetaData2);
			meta3Label->setText("Software          : " + strMetaData3);
			meta4Label->setText("Image width       : " + strMetaData4);
			meta5Label->setText("Image height      : " + strMetaData5);
			meta6Label->setText("Image orientation : " + strMetaData6);
			meta7Label->setText("Image date/time   : " + strMetaData7);
			meta8Label->setText("Original date/time: " + strMetaData8);
			meta9Label->setText("Digitize date/time: " + strMetaData9);
			meta10Label->setText("Subsecond time    : " + strMetaData10);
			meta11Label->setText("Exposure time     : " + strMetaData11);
			meta12Label->setText("F-stop            : " + strMetaData12);
			meta13Label->setText("ISO speed         : " + strMetaData13);
			meta14Label->setText("Metering mode     : " + strMetaData14);
			meta15Label->setText("Lens focal length : " + strMetaData15);
			meta16Label->setText("35mm focal length : " + strMetaData16);
		}
}
void MainWindow::openImage(const QString &path)
{
filePath=path;
if (filePath.isNull())
{filePath=QFileDialog::getOpenFileName(this,tr("Open image"),"","Image Files (*.png *.jpg *.bmp)");
if (!filePath.isEmpty())
{ if(!newImage.load(filePath))
{QMessageBox::warning(this,tr("Open Image"),tr("The image file could be loaded"),QMessageBox::Cancel);
return;
}
}
}
}
void MainWindow::paintEvent(QPaintEvent *)
{
QPixmap bgPixmap(filePath);
QPixmap scaled = bgPixmap.scaled(QSize(W, H));
QPainter myPainter(this);
myPainter.drawPixmap(0,215,scaled);
}
