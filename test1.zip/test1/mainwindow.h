#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QtWidgets>
QT_BEGIN_NAMESPACE
class QLabel;
class QPainter;
class QLineEdit;
class QPushButton;
QT_END_NAMESPACE
class MainWindow:public QMainWindow
{
Q_OBJECT
public:
	MainWindow();
private slots:
	void openButtonClick();
	void changeButtonClick();
protected:
	void paintEvent(QPaintEvent *event);
	void openImage(const QString &path = QString());
private: 
	QLabel *wLabel;
	QLineEdit *wEdit;
	QLabel *hLabel;
	QLineEdit *hEdit;
	QLabel *labLabel;
	QLabel *lab1Label;
	QLabel *fileLabel;
	QLabel *metaLabel;
	QLabel *meta1Label;
	QLabel *meta2Label;
	QLabel *meta3Label;
	QLabel *meta4Label;
	QLabel *meta5Label;
	QLabel *meta6Label;
	QLabel *meta7Label;
	QLabel *meta8Label;
	QLabel *meta9Label;
	QLabel *meta10Label;
	QLabel *meta11Label;
	QLabel *meta12Label;
	QLabel *meta13Label;
	QLabel *meta14Label;
	QLabel *meta15Label;
	QLabel *meta16Label;
	QPainter *myPainter;
	QPixmap newImage;
	QLineEdit *pathEdit;
	QPushButton *openButton;
	QPushButton *changeButton;
};
#endif